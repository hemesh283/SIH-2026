package com.example.gudumap.sensors

import android.location.Location
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class DeadReckoningState(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val speed: Float = 0f,
    val heading: Float = 0f,
    val distanceTravelled: Double = 0.0,
    val isInitialized: Boolean = false
)

class DeadReckoningEngine {

    companion object {

        private const val EARTH_RADIUS = 6_371_000.0

        private const val MIN_DT = 0.001

        private const val MAX_DT = 0.2

        /*
         * Small acceleration values are treated as
         * sensor noise.
         */
        private const val ACCELERATION_THRESHOLD = 0.12

        /*
         * Damping prevents unlimited velocity growth
         * from small IMU errors.
         */
        private const val VELOCITY_DAMPING = 0.995
    }

    private var latitude = 0.0

    private var longitude = 0.0

    private var velocityNorth = 0.0

    private var velocityEast = 0.0

    private var lastTimestamp = 0L

    private var totalDistance = 0.0

    private var initialized = false


    /**
     * Start DR from a known GNSS position.
     */
    fun initialize(location: Location) {

        latitude = location.latitude

        longitude = location.longitude

        if (location.hasSpeed()) {

            val speed =
                location.speed.toDouble()

            val bearing =
                if (location.hasBearing()) {
                    Math.toRadians(
                        location.bearing.toDouble()
                    )
                } else {
                    0.0
                }

            velocityNorth =
                speed * cos(bearing)

            velocityEast =
                speed * sin(bearing)

        } else {

            velocityNorth = 0.0

            velocityEast = 0.0
        }

        totalDistance = 0.0

        lastTimestamp =
            System.nanoTime()

        initialized = true
    }


    /**
     * Update DR using world-frame acceleration.
     */
    fun update(

        accelerationNorth: Float,

        accelerationEast: Float,

        heading: Float

    ): DeadReckoningState {

        if (!initialized) {
            return getState()
        }

        val now =
            System.nanoTime()

        var dt =
            (now - lastTimestamp) /
                    1_000_000_000.0

        if (dt < MIN_DT) {
            return getState()
        }

        if (dt > MAX_DT) {
            dt = MAX_DT
        }

        lastTimestamp = now


        /*
         * Remove tiny acceleration noise.
         */
        val northAcceleration =

            if (
                abs(
                    accelerationNorth.toDouble()
                ) < ACCELERATION_THRESHOLD
            ) {
                0.0
            } else {
                accelerationNorth.toDouble()
            }


        val eastAcceleration =

            if (
                abs(
                    accelerationEast.toDouble()
                ) < ACCELERATION_THRESHOLD
            ) {
                0.0
            } else {
                accelerationEast.toDouble()
            }


        /*
         * Acceleration → velocity
         */
        velocityNorth +=
            northAcceleration * dt

        velocityEast +=
            eastAcceleration * dt


        /*
         * Damping.
         *
         * This is only a temporary prototype
         * correction. EKF will replace this later.
         */
        velocityNorth *=
            VELOCITY_DAMPING

        velocityEast *=
            VELOCITY_DAMPING


        /*
         * Prevent tiny velocities from
         * continuously accumulating.
         */
        if (
            abs(velocityNorth) < 0.03 &&
            abs(velocityEast) < 0.03
        ) {

            velocityNorth = 0.0

            velocityEast = 0.0
        }


        /*
         * Velocity → displacement
         */
        val displacementNorth =
            velocityNorth * dt

        val displacementEast =
            velocityEast * dt


        val displacement =
            sqrt(
                displacementNorth *
                        displacementNorth +

                        displacementEast *
                        displacementEast
            )


        totalDistance +=
            displacement


        /*
         * Convert North displacement
         * to latitude.
         */
        latitude += Math.toDegrees(
            displacementNorth /
                    EARTH_RADIUS
        )


        /*
         * Convert East displacement
         * to longitude.
         */
        val latitudeRadians =
            Math.toRadians(latitude)

        val longitudeScale =
            EARTH_RADIUS *
                    cos(latitudeRadians)

        if (
            abs(longitudeScale) >
            0.000001
        ) {

            longitude +=
                Math.toDegrees(
                    displacementEast /
                            longitudeScale
                )
        }


        return getState(
            heading
        )
    }


    /**
     * Correct DR using GNSS.
     */
    fun correctWithGnss(
        location: Location
    ) {

        if (!initialized) {

            initialize(location)

            return
        }


        latitude =
            location.latitude

        longitude =
            location.longitude


        /*
         * GPS speed/bearing provides
         * a good velocity correction.
         */
        if (
            location.hasSpeed() &&
            location.hasBearing()
        ) {

            val speed =
                location.speed.toDouble()

            val bearing =
                Math.toRadians(
                    location.bearing.toDouble()
                )

            velocityNorth =
                speed * cos(bearing)

            velocityEast =
                speed * sin(bearing)
        }


        lastTimestamp =
            System.nanoTime()
    }


    private fun getState(
        suppliedHeading: Float? = null
    ): DeadReckoningState {

        val speed =
            sqrt(
                velocityNorth *
                        velocityNorth +

                        velocityEast *
                        velocityEast
            )


        val calculatedHeading =

            if (speed > 0.1) {

                var value =
                    Math.toDegrees(
                        atan2(
                            velocityEast,
                            velocityNorth
                        )
                    ).toFloat()

                if (value < 0f) {
                    value += 360f
                }

                value

            } else {

                suppliedHeading ?: 0f
            }


        return DeadReckoningState(

            latitude =
                latitude,

            longitude =
                longitude,

            speed =
                speed.toFloat(),

            heading =
                calculatedHeading,

            distanceTravelled =
                totalDistance,

            isInitialized =
                initialized
        )
    }


    fun getState():
            DeadReckoningState {

        return getState(null)
    }


    fun reset() {

        latitude = 0.0

        longitude = 0.0

        velocityNorth = 0.0

        velocityEast = 0.0

        lastTimestamp = 0L

        totalDistance = 0.0

        initialized = false
    }
}